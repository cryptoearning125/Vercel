
import * as React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Rss, Waves, Eye } from 'lucide-react';

const InfoCard = ({ icon, title, children }: { icon: React.ReactNode; title: string; children: React.ReactNode; }) => (
    <div className="bg-card rounded-xl p-6 shadow-sm dark:shadow-none border border-border">
        <div className="flex items-start gap-4">
            <div className="flex-shrink-0 text-primary mt-1">{icon}</div>
            <div>
                <h3 className="text-xl font-bold text-card-foreground mb-2">
                    {title}
                </h3>
                <div className="text-muted-foreground leading-relaxed">
                    {children}
                </div>
            </div>
        </div>
    </div>
);

const ColorScienceScreen = () => {
    const navigate = useNavigate();

    return (
        <div className="bg-background text-foreground min-h-screen font-sans">
             <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-lg">
                <div className="max-w-4xl mx-auto p-4 flex items-center">
                    <button onClick={() => navigate(-1)} className="p-2 mr-2 rounded-full hover:bg-secondary">
                        <ArrowLeft size={24} />
                    </button>
                    <h1 className="text-2xl font-bold">The Science of Color</h1>
                </div>
            </header>
            <main className="max-w-4xl mx-auto p-4 md:p-6 space-y-8 pb-24">
                
                <InfoCard icon={<Rss size={24} />} title="White Light is a Spectrum">
                    <p>
                        Light from sources like the sun or a lightbulb appears "white," but it's actually made up of a whole spectrum of different colors. You can see this when light passes through a prism or in a rainbow.
                    </p>
                </InfoCard>

                <InfoCard icon={<Waves size={24} />} title="Wavelengths and the Electromagnetic Spectrum">
                    <p>
                        Light is a form of energy that travels in waves. The length of these waves determines the color. The range of all possible wavelengths is called the electromagnetic spectrum, and the tiny part we can see is called the visible light spectrum.
                    </p>
                    <p className="mt-4">
                        Each color in the visible spectrum has a different wavelength. Red has the longest wavelength, and violet has the shortest. The famous acronym <strong className="font-semibold text-foreground">ROY G. BIV</strong> lists them in order: Red, Orange, Yellow, Green, Blue, Indigo, Violet.
                    </p>
                </InfoCard>
                
                <InfoCard icon={<Eye size={24} />} title="How We Perceive Color">
                     <p>
                        When light hits an object, the object's surface absorbs some wavelengths and reflects others. The color we see is the wavelength that is reflected back to our eyes.
                    </p>
                </InfoCard>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center bg-card p-6 rounded-xl border border-border">
                    <div className="order-2 md:order-1">
                        <h3 className="text-2xl font-bold text-success mb-3">Example: A Green Leaf</h3>
                        <p className="text-muted-foreground leading-relaxed">
                           A leaf appears green because its surface, containing chlorophyll, absorbs the red and blue wavelengths of light but reflects the green wavelengths. Our eyes detect these reflected green waves, so our brain perceives the color "green".
                        </p>
                    </div>
                    <div className="order-1 md:order-2">
                        <img 
                            src="https://images.unsplash.com/photo-1596756641982-f435099359a3?q=80&w=1000&auto=format&fit=crop" 
                            alt="A green leaf" 
                            className="w-full h-auto object-cover rounded-lg shadow-lg"
                        />
                    </div>
                </div>

            </main>
        </div>
    );
};

export default ColorScienceScreen;