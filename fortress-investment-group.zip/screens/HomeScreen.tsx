
import * as React from 'react';
import { useNavigate } from 'react-router-dom';
import { CreditCard, Download, Scale, Headset, Volume2, Gift, Users, MessageSquare, ShieldCheck } from 'lucide-react';
import type { CryptoCoin } from '../types.ts';
import { useAuth } from '../contexts/AuthContext.tsx';
import { MOCK_CRYPTO_COINS } from '../lib/mock-market-data.ts';

const iconMap: { [key: string]: React.ElementType } = {
  CreditCard,
  Download,
  Scale,
  Headset,
  Gift,
  Users,
  MessageSquare,
  ShieldCheck,
};

const carouselSlides = [
    {
        bg: 'https://images.unsplash.com/photo-1639755243242-73a67fd7a40b?q=80&w=2070&auto=format&fit=crop',
        title: "SECURE & RELIABLE",
        subtitle: "trade with confidence",
        logos: [
            'https://s2.coinmarketcap.com/static/img/exchanges/64x64/22.png',
            'https://s2.coinmarketcap.com/static/img/exchanges/64x64/73.png',
            'https://s2.coinmarketcap.com/static/img/exchanges/64x64/37.png',
            'https://s2.coinmarketcap.com/static/img/exchanges/64x64/24.png',
            'https://s2.coinmarketcap.com/static/img/exchanges/64x64/36.png',
        ]
    }
];

const HomeScreen = () => {
    const navigate = useNavigate();
    const { systemSettings } = useAuth();
    const [activeSlide, setActiveSlide] = React.useState(0);
    const [activeTab, setActiveTab] = React.useState('Hot');
    const [marketData, setMarketData] = React.useState<CryptoCoin[]>([]);
    const [loading, setLoading] = React.useState(true);

    const actionMenuItems = React.useMemo(() => {
        const defaultItems = [
            { id: 'recharge', icon: CreditCard, label: 'Recharge', path: '/profile', state: { view: 'deposit' } },
            { id: 'withdraw', icon: Download, label: 'Withdraw', path: '/profile', state: { view: 'withdraw' } },
            { id: 'balance', icon: Scale, label: 'Balance', path: '/profile', state: {} },
            { id: 'support', icon: Headset, label: 'Support', path: 'https://t.me/FortressInvestmentSupport' },
        ];

        if (systemSettings?.homepageActionItems) {
            return systemSettings.homepageActionItems
                .filter(item => item.enabled)
                .sort((a, b) => a.order - b.order)
                .map(item => ({...item, icon: iconMap[item.icon] || Headset }));
        }
        
        return defaultItems;
    }, [systemSettings]);


    React.useEffect(() => {
        const fetchCoinData = async () => {
            if (!loading) setLoading(true);
            try {
                const response = await fetch('https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=10&page=1&sparkline=false');
                if (!response.ok) {
                    throw new Error('Failed to fetch data from CoinGecko API');
                }
                const data: CryptoCoin[] = await response.json();
                setMarketData(data);
            } catch (err) {
                console.error("Failed to fetch live market data, falling back to mock data.", err);
                setMarketData(MOCK_CRYPTO_COINS.slice(0, 10));
            } finally {
                setLoading(false);
            }
        };

        fetchCoinData();
        const intervalId = setInterval(fetchCoinData, 30000);

        return () => clearInterval(intervalId);
    }, []);
    
    React.useEffect(() => {
        if (carouselSlides.length <= 1) return;
        const timer = setTimeout(() => {
            setActiveSlide((prev) => (prev + 1) % carouselSlides.length);
        }, 5000);
        return () => clearTimeout(timer);
    }, [activeSlide]);

    const handleActionClick = (path: string, state?: any) => {
        if (path.startsWith('http')) {
            window.open(path, '_blank', 'noopener,noreferrer');
        } else {
            navigate(path, { state });
        }
    };
    
    const MarketRow = ({ coin }: { coin: CryptoCoin }) => {
        const isPositive = (coin.price_change_percentage_24h || 0) >= 0;
        const changeColor = isPositive ? 'text-success' : 'text-destructive';
        const changeSign = isPositive ? '+' : '';

        return (
            <div 
                className="grid grid-cols-3 items-center py-3 px-2 rounded-md hover:bg-secondary cursor-pointer"
                onClick={() => navigate(`/trading/${coin.symbol.toUpperCase()}-USDT`)}
            >
                <div className="text-left">
                    <p className="font-bold">{coin.symbol.toUpperCase()}/USDT</p>
                </div>
                <p className="text-center font-semibold">{coin.current_price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 6 })}</p>
                <p className={`text-right font-semibold ${changeColor}`}>{changeSign}{(coin.price_change_percentage_24h || 0).toFixed(2)}%</p>
            </div>
        );
    };

    return (
        <div className="bg-background text-foreground min-h-screen pb-24 font-sans">
            <header className="py-4">
                <h1 className="text-xl font-bold text-center">Home</h1>
            </header>

            <main className="px-4 space-y-6">
                {/* Carousel */}
                <div className="relative w-full h-44 bg-card rounded-lg overflow-hidden group">
                    {carouselSlides.map((slide, index) => (
                        <div key={index} className={`absolute inset-0 transition-opacity duration-1000 ${index === activeSlide ? 'opacity-100' : 'opacity-0'}`}>
                            <img src={slide.bg} alt={slide.title} className="w-full h-full object-cover"/>
                            <div className="absolute inset-0 bg-black/60 p-6 flex flex-col justify-between">
                                <div>
                                    <h2 className="text-2xl font-bold uppercase text-white">{slide.title}</h2>
                                    <h3 className="text-xl uppercase text-slate-200">{slide.subtitle}</h3>
                                </div>
                                <div className="flex items-center space-x-4">
                                    {slide.logos.map((logo, logoIndex) => (
                                        <img key={logoIndex} src={logo} alt="exchange logo" className="h-8 w-8 bg-white/20 rounded-full p-1"/>
                                    ))}
                                </div>
                            </div>
                        </div>
                    ))}
                     <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex space-x-2">
                        {carouselSlides.map((_, index) => (
                            <button key={index} onClick={() => setActiveSlide(index)} className={`w-2 h-2 rounded-full transition-colors ${index === activeSlide ? 'bg-accent-gold' : 'bg-muted-foreground'}`}></button>
                        ))}
                    </div>
                </div>

                {/* Announcement Bar */}
                <div className="flex items-center space-x-3 bg-secondary p-2 rounded-lg text-sm overflow-hidden">
                    <Volume2 size={20} className="text-accent-gold flex-shrink-0" />
                    <div className="flex-grow relative h-5">
                        <p className="absolute whitespace-nowrap animate-marquee">Upgrade Announcement: System maintenance will be performed this Sunday from 2 AM to 4 AM UTC.</p>
                    </div>
                    <button className="text-accent-gold font-semibold flex-shrink-0">More&gt;</button>
                </div>

                {/* Quick Action Menu */}
                <div className="grid grid-cols-4 gap-4 text-center">
                    {actionMenuItems.map((item) => (
                        <button key={item.id} onClick={() => handleActionClick(item.path, item.state)} className="flex flex-col items-center space-y-2">
                            <item.icon size={28} className="text-accent-gold" />
                            <span className="text-sm font-medium">{item.label}</span>
                        </button>
                    ))}
                </div>

                {/* Market Data */}
                <div>
                    <div className="flex space-x-6 border-b border-border mb-2">
                        <button onClick={() => setActiveTab('Hot')} className={`py-2 font-semibold ${activeTab === 'Hot' ? 'text-accent-gold border-b-2 border-accent-gold' : 'text-foreground'}`}>
                            Hot
                        </button>
                         <button onClick={() => setActiveTab('Commodity')} className={`py-2 font-semibold ${activeTab === 'Commodity' ? 'text-accent-gold border-b-2 border-accent-gold' : 'text-foreground'}`}>
                            Commodity
                        </button>
                    </div>

                    <div>
                        <div className="grid grid-cols-3 text-sm text-muted-foreground mb-2 px-2">
                            <p className="text-left">Products</p>
                            <p className="text-center">Last price</p>
                            <p className="text-right">24H Increase</p>
                        </div>
                        <div className="space-y-1">
                            {loading && <p className="text-center text-muted-foreground py-4">Loading...</p>}
                            {!loading && activeTab === 'Hot' && marketData.map(coin => <MarketRow key={coin.id} coin={coin} />)}
                            {!loading && activeTab === 'Commodity' && <p className="text-center text-muted-foreground py-4">Commodity data not available.</p>}
                        </div>
                    </div>
                </div>
            </main>
        </div>
    );
};

export default HomeScreen;
