
import * as React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Trophy, BarChart, Network } from 'lucide-react';

const FeatureHighlight = ({ icon, title }: { icon: React.ReactNode; title: string; }) => (
    <div className="bg-card rounded-xl p-6 shadow-sm dark:shadow-none border border-border text-center flex flex-col items-center justify-center">
        {icon}
        <p className="text-lg font-bold text-card-foreground mt-3">
            {title}
        </p>
    </div>
);

const PillarItem = ({ title, children }: { title: string; children: React.ReactNode }) => (
    <div className="bg-card rounded-xl p-6 shadow-sm dark:shadow-none border border-border">
        <h3 className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-500 to-blue-500 mb-3">
            {title}
        </h3>
        <p className="text-muted-foreground leading-relaxed">
            {children}
        </p>
    </div>
);

const AboutScreen = () => {
    const navigate = useNavigate();

    return (
        <div className="bg-background text-foreground min-h-screen font-sans">
             <header className="sticky top-0 z-10 bg-background/80 backdrop-blur-lg">
                <div className="max-w-4xl mx-auto p-4 flex items-center">
                    <button onClick={() => navigate(-1)} className="p-2 mr-2 rounded-full hover:bg-secondary">
                        <ArrowLeft size={24} />
                    </button>
                    <h1 className="text-2xl font-bold">About Fortress</h1>
                </div>
            </header>
            <main className="max-w-4xl mx-auto p-4 md:p-6 space-y-12 pb-24">
                
                <section className="text-center">
                    <h2 className="text-4xl font-extrabold mb-4">Investment Platform</h2>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8 mt-8">
                        <FeatureHighlight icon={<Network size={36} className="text-primary"/>} title="Proprietary Sourcing Network" />
                        <FeatureHighlight icon={<Trophy size={36} className="text-blue-500"/>} title="Deep Underwriting Expertise" />
                        <FeatureHighlight icon={<BarChart size={36} className="text-success"/>} title="Rigorous Asset Management" />
                    </div>
                </section>

                <section>
                    <div className="bg-gradient-to-r from-purple-500 to-blue-500 p-1 rounded-2xl">
                        <div className="bg-secondary p-8 rounded-xl">
                            <h3 className="text-3xl font-bold text-center mb-4">One Platform</h3>
                            <p className="text-center text-muted-foreground leading-relaxed text-lg">
                                From our proprietary sourcing network to our experienced team of asset managers, our exceptional resources and personnel inform everything we do. Our more than 200 investment professionals are seasoned, creative, and laser-focused on generating superior risk-adjusted returns across asset classes, geographies and structures.
                            </p>
                        </div>
                    </div>
                </section>
                
                <section className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8">
                    <PillarItem title="Experience Across Credit Cycles">
                        As one of the pioneers of private credit, Fortress has earned a reputation as a meticulous credit investor. Our experience extends across all our investment groups, creating valuable cross-class expertise.
                    </PillarItem>
                    <PillarItem title="Fundamental Credit Focus and Structured Approach">
                        We are an active, fundamental value, asset-based investor. We are laser-focused on properly pricing, structuring, collateralizing and monitoring to maximize the value of credit investments.
                    </PillarItem>
                    <PillarItem title="Investment Flexibility">
                        We pursue a broad, diversified strategy covering multiple asset classes and structures. This allows us to seize opportunities requiring specialization in more than one investment category and to underwrite diverse pools of credits.
                    </PillarItem>
                    <PillarItem title="Active Asset Management">
                        Fortress is extremely active in maximizing the value of investments through hands-on asset management, with over 150 dedicated asset management professionals across three continents.
                    </PillarItem>
                </section>

                <footer className="text-center text-sm text-muted-foreground pt-8 border-t border-border">
                    <p>As of June 30, 2024.</p>
                </footer>
            </main>
        </div>
    );
};

export default AboutScreen;